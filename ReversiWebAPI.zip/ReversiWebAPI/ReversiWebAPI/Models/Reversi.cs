﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace ReversiWebAPI.Models
{
    public class ReversiModel
    {
        /// <summary>
        /// 玩家
        /// </summary>
        public string playper { get; set; }
        /// <summary>
        /// 棋盤
        /// </summary>
        public string board { get; set; }
        /// <summary>
        /// 深度# 2 ~ 7
        /// </summary>
        public int maxDepth { get; set; }
    }
    public class ReversiObj: ReversiModel
    {
        public ReversiObj(ReversiModel model)
        {
            this.playper = model.playper;
            this.board = model.board;
            this.maxDepth = model.maxDepth;
        }
        /// <summary>
        /// 是否有錯誤訊息
        /// </summary>
        public bool hasError { get { return !string.IsNullOrWhiteSpace(this.error); } }
        /// <summary>
        /// 錯誤訊息
        /// </summary>
        public string error { get; private set; }

        /// <summary>
        /// 取得棋盤物件
        /// </summary>
        public List<List<string>> Board
        {
            get
            {
                try
                {
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<List<List<string>>>(this.board);
                }
                catch (Exception ex)
                {
                    this.error = ex.Message;
                }
                return new List<List<string>>();
            }
        }

        public DiscColor color
        {
            get
            {
                switch (this.playper)
                {
                    case "0":
                        return DiscColor.White;
                    case "1":
                        return DiscColor.Black;
                    default:
                        return DiscColor.None;
                }
            }
        }
    }

    #region Board

    public class Board : ICloneable
    {
        #region ReadOnly

        public const int DEFAULT_BOARD_SIZE = 8;

        #endregion


        #region Fields

        private int mBoardSize;

        private DiscColor[,] mFieldColors;

        private int mInvertedDiscsLastMove = 0;

        #endregion

        #region Constructors

        public Board(List<List<string>> pBoard)
        {
            this.mBoardSize = pBoard.Count;
            this.mFieldColors = new DiscColor[this.mBoardSize, this.mBoardSize];

            for (int rowIndex = 0; rowIndex < this.mBoardSize; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < this.mBoardSize; columnIndex++)
                {
                    switch (pBoard[columnIndex][rowIndex])
                    {
                        case "WHITE_TILE":
                            this.mFieldColors[rowIndex, columnIndex] = DiscColor.White;
                            break;
                        case "BLACK_TILE":
                            this.mFieldColors[rowIndex, columnIndex] = DiscColor.Black;
                            break;
                        case "None":
                        default:
                            this.mFieldColors[rowIndex, columnIndex] = DiscColor.None;
                            break;
                    }
                }
            }
        }

        private Board(Board orignalBoard)
        {
            this.mBoardSize = orignalBoard.Size;
            this.mFieldColors = new DiscColor[this.Size, this.Size];

            for (int rowIndex = 0; rowIndex < this.Size; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < this.Size; columnIndex++)
                {
                    this.mFieldColors[rowIndex, columnIndex] = orignalBoard[rowIndex, columnIndex];
                }
            }
        }

        #endregion

        #region Properties

        public int Size
        {
            get
            {
                return this.mBoardSize;
            }
        }

        public DiscColor this[int rowIndex, int columnIndex]
        {
            get
            {
                return this.mFieldColors[rowIndex, columnIndex];
            }
        }

        public int InvertedDiscsLastMove
        {
            get
            {
                return this.mInvertedDiscsLastMove;
            }
        }

        #endregion

        #region Methods

        public void SetFieldColor(int rowIndex, int columnIndex, DiscColor color)
        {
            if (this.CanSetFieldColor(rowIndex, columnIndex, color))
            {
                this.mFieldColors[rowIndex, columnIndex] = color;
                this.InvertOpponentDisks(rowIndex, columnIndex, color, out this.mInvertedDiscsLastMove);

            }
        }

        public bool CanSetFieldColor(int rowIndex, int columnIndex, DiscColor color)
        {
            bool hasColor = (this[rowIndex, columnIndex] != DiscColor.None);

            if (!hasColor)
            {
                if (color == DiscColor.None)
                {
                    return true;
                }
                else
                {
                    for (int rowIndexChange = -1; rowIndexChange <= 1; rowIndexChange++)
                    {
                        for (int columnIndexChange = -1; columnIndexChange <= 1; columnIndexChange++)
                        {
                            if ((rowIndexChange != 0) || (columnIndexChange != 0))
                            {
                                if (this.CheckDirection(rowIndex, columnIndex, rowIndexChange, columnIndexChange, color))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        private bool CheckDirection(int rowIndex, int columnIndex, int rowIndexChange, int columnIndexChange, DiscColor color)
        {
            bool areOpositeColorDiscsFound = false;
            rowIndex += rowIndexChange;
            columnIndex += columnIndexChange;
            while ((rowIndex >= 0) && (rowIndex < this.Size) && (columnIndex >= 0) && (columnIndex < this.Size))
            {
                if (areOpositeColorDiscsFound)
                {
                    if (this[rowIndex, columnIndex] == color)
                    {
                        return true;
                    }
                    else if (this[rowIndex, columnIndex] == DiscColor.None)
                    {
                        return false;
                    }
                }
                else
                {
                    DiscColor opositeColor = DiscColor.GetOpposite(color);
                    if (this[rowIndex, columnIndex] == opositeColor)
                    {
                        areOpositeColorDiscsFound = true;
                    }
                    else
                    {
                        return false;
                    }
                }

                rowIndex += rowIndexChange;
                columnIndex += columnIndexChange;
            }

            return false;
        }

        public bool CanSetAnyField(DiscColor color)
        {
            for (int rowIndex = 0; rowIndex < this.Size; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < this.Size; columnIndex++)
                {
                    if (this.CanSetFieldColor(rowIndex, columnIndex, color))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public int GetDiscsCount(DiscColor color)
        {
            int result = 0;
            for (int rowIndex = 0; rowIndex < this.Size; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < this.Size; columnIndex++)
                {
                    if (this[rowIndex, columnIndex] == color)
                    {
                        result++;
                    }
                }
            }
            return result;
        }

        private void InvertOpponentDisks(int rowIndex, int columnIndex, DiscColor color, out int invertedDiscsCount)
        {
            invertedDiscsCount = 0;
            for (int rowIndexChange = -1; rowIndexChange <= 1; rowIndexChange++)
            {
                for (int columnIndexChange = -1; columnIndexChange <= 1; columnIndexChange++)
                {
                    if ((rowIndexChange != 0) || (columnIndexChange != 0))
                    {
                        if (this.CheckDirection(rowIndex, columnIndex, rowIndexChange, columnIndexChange, color))
                        {
                            this.InvertDirection(rowIndex, columnIndex, rowIndexChange, columnIndexChange, color, ref invertedDiscsCount);
                        }
                    }
                }
            }
        }
        private void InvertDirection(
            int rowIndex, int columnIndex,
            int rowIndexChange, int columnIndexChange,
            DiscColor color,
            ref int invertedDiscsCount)
        {
            DiscColor opositeColor = DiscColor.GetOpposite(color);

            rowIndex += rowIndexChange;
            columnIndex += columnIndexChange;
            while (this[rowIndex, columnIndex] == opositeColor)
            {
                this.mFieldColors[rowIndex, columnIndex] = color;
                invertedDiscsCount++;

                rowIndex += rowIndexChange;
                columnIndex += columnIndexChange;
            }
        }

        public object Clone()
        {
            return new Board(this);
        }

        #endregion
    }

    #endregion

    #region DiscColor

    public class DiscColor
    {
        private Color mColor;

        private DiscColor(Color color)
        {
            this.mColor = color;
        }

        public Color Color
        {
            get
            {
                return this.mColor;
            }
        }

        public static readonly DiscColor Black = new DiscColor(Color.Black);
        public static readonly DiscColor White = new DiscColor(Color.White);
        public static readonly DiscColor None = new DiscColor(Color.Empty);

        public static DiscColor GetOpposite(DiscColor color)
        {
            if (color == DiscColor.Black)
            {
                return DiscColor.White;
            }
            else if (color == DiscColor.White)
            {
                return DiscColor.Black;
            }
            else
            {
                return DiscColor.None;
            }
        }
    }

    #endregion

    #region Player

    public enum PlayerType
    {
        Human,
        Computer
    }

    public abstract class Player
    {
        #region Fields

        protected DiscColor mColor;

        protected string mName;

        #endregion

        #region Constructors

        internal Player(DiscColor color, string name)
        {

            this.mColor = color;
            this.mName = name;
        }

        #endregion

        #region Properties


        public DiscColor Color
        {
            get
            {
                return this.mColor;
            }
        }

        public string Name
        {
            get
            {
                return this.mName;
            }
        }

        public abstract PlayerType Type
        {
            get;
        }

        #endregion
    }

    class ComputerPlayer : Player
    {
        #region Static

        public static readonly int MinDepth = 2;
        public static readonly int MaxDepth = 7;

        #endregion

        #region ReadOnly

        private int mMaxDepth;

        #endregion

        #region Constructors

        public ComputerPlayer(DiscColor color, string name, int maxDepth)
            : base(color, name)
        {
            this.mMaxDepth = maxDepth;
        }

        #endregion

        #region Properties

        public override PlayerType Type
        {
            get
            {
                return PlayerType.Computer;
            }
        }

        private int Depth
        {
            get
            {
                return this.mMaxDepth;
            }
        }

        #endregion
    }
    #endregion

    #region MoveSolver

    class MoveSolver
    {
        #region ReadOnly

        private const int MAX_BOARD_VALUE = Int32.MaxValue;
        private const int MIN_BOARD_VALUE = -MAX_BOARD_VALUE;

        #endregion        

        #region Fields

        private Player mPlayer;
        private int mMaxDepth;
        private Board mBoard;
        #endregion

        #region Constructors

        public MoveSolver(List<List<string>>pBoard, Player player, int maxDepth)
        {
            this.mPlayer = player;
            this.mMaxDepth = maxDepth;
            this.mBoard = new Board(pBoard);
        }

        #endregion        

        #region Properties

        public Player Player
        {
            get
            {
                return this.mPlayer;
            }
        }

        public int MaxDepth
        {
            get
            {
                return this.mMaxDepth;
            }
        }

        #endregion

        #region Methods

        public void GetNextMove(out int rowIndex, out int columnIndex)
        {
            this.GetNextMove(this.mBoard, true, 1, MIN_BOARD_VALUE, MAX_BOARD_VALUE, out rowIndex, out columnIndex);
        }

        private int GetNextMove(Board board, bool isMaximizing, int currentDepth, int alpha, int beta, out int resultRowIndex, out int resultColumnIndex)
        {
            resultRowIndex = 0;
            resultColumnIndex = 0;

            DiscColor color = isMaximizing ? this.Player.Color : DiscColor.GetOpposite(this.Player.Color);
            bool playerSkipsMove = false;
            List<int[]> possibleMoves = new List<int[]>();

            bool isFinalMove = (currentDepth >= this.MaxDepth);

            if (!isFinalMove)
            {
                possibleMoves = this.GetPossibleMoves(board, color);
                if (possibleMoves.Count == 0)
                {
                    playerSkipsMove = true;
                    possibleMoves = this.GetPossibleMoves(board, DiscColor.GetOpposite(color));
                }

                isFinalMove = (possibleMoves.Count == 0);
            }

            if (isFinalMove)
            {
                resultRowIndex = -1;
                resultColumnIndex = -1;
                return this.EvaluateBoard(board);
            }
            else
            {
                int bestBoardValue = isMaximizing ? MIN_BOARD_VALUE : MAX_BOARD_VALUE;
                int bestMoveRowIndex = -1;
                int bestMoveColumnIndex = -1;

                foreach (int[] nextMove in possibleMoves)
                {
                    int rowIndex = nextMove[0];
                    int columnIndex = nextMove[1];

                    Board nextBoard = (Board)board.Clone();
                    nextBoard.SetFieldColor(rowIndex, columnIndex, color);

                    bool nextIsMaximizing = playerSkipsMove ? isMaximizing : !isMaximizing;

                    int dummyIndex; // values of resultRowIndex and resultColumnIndex are not needed in recursive function calls
                    int currentBoardValue = this.GetNextMove(nextBoard, nextIsMaximizing, currentDepth + 1, alpha, beta, out dummyIndex, out dummyIndex);
                    if (isMaximizing)
                    {
                        if (currentBoardValue > bestBoardValue)
                        {
                            bestBoardValue = currentBoardValue;
                            bestMoveRowIndex = rowIndex;
                            bestMoveColumnIndex = columnIndex;

                            if (bestBoardValue > alpha)
                            {
                                alpha = bestBoardValue;
                            }

                            if (bestBoardValue >= beta)
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        if (currentBoardValue < bestBoardValue)
                        {
                            bestBoardValue = currentBoardValue;
                            bestMoveRowIndex = rowIndex;
                            bestMoveColumnIndex = columnIndex;

                            if (bestBoardValue < beta)
                            {
                                beta = bestBoardValue;
                            }

                            if (bestBoardValue <= alpha)
                            {
                                break;
                            }
                        }
                    }
                }

                resultRowIndex = bestMoveRowIndex;
                resultColumnIndex = bestMoveColumnIndex;
                return bestBoardValue;
            }
        }

        private List<int[]> GetPossibleMoves(Board board, DiscColor color)
        {
            List<int[]> possibleMoves = new List<int[]>();
            for (int rowIndex = 0; rowIndex < board.Size; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < board.Size; columnIndex++)
                {
                    if (board.CanSetFieldColor(rowIndex, columnIndex, color))
                    {
                        possibleMoves.Add(new int[2] { rowIndex, columnIndex });
                    }
                }
            }

            List<int> indexes = this.GetRandomIndexes(possibleMoves.Count);
            List<int[]> result = new List<int[]>();
            foreach (int index in indexes)
            {
                result.Add(possibleMoves[index]);
            }
            //return result;
            return possibleMoves;
        }

        private List<int> GetRandomIndexes(int count)
        {
            int minValue = 0;
            int maxValue = count;
            List<int> result = new List<int>();
            Random random = new Random();

            while (result.Count < count)
            {
                int next = random.Next(minValue, maxValue);
                if (!result.Contains(next))
                {
                    result.Add(next);
                }

                if (next == minValue)
                {
                    minValue++;
                }
                else if (next == maxValue - 1)
                {
                    maxValue--;
                }
            }

            return result;
        }

        private int EvaluateBoard(Board board)
        {
            DiscColor color = this.Player.Color;
            DiscColor oppositeColor = DiscColor.GetOpposite(this.Player.Color);

            List<int[]> oppositePlayerPossibleMoves = this.GetPossibleMoves(board, oppositeColor);
            List<int[]> possibleMoves = this.GetPossibleMoves(board, color);

            if ((possibleMoves.Count == 0) && (oppositePlayerPossibleMoves.Count == 0))
            {
                int result = board.GetDiscsCount(color) - board.GetDiscsCount(oppositeColor);
                int addend = (int)Math.Pow(board.Size, 4) + (int)Math.Pow(board.Size, 3); // because it is a terminal state, its weight must be bigger than the heuristic ones
                if (result < 0)
                {
                    addend = -addend;
                }
                return result + addend;
            }
            else
            {
                int mobility = this.GetPossibleConvertions(board, color, possibleMoves)
                    - this.GetPossibleConvertions(board, oppositeColor, oppositePlayerPossibleMoves);
                int stability = (this.GetStableDiscsCount(board, color) - this.GetStableDiscsCount(board, oppositeColor)) * board.Size * 2 / 3;

                return mobility + stability;
            }
        }

        private int GetPossibleConvertions(Board board, DiscColor color, List<int[]> possibleMoves)
        {
            int result = 0;
            foreach (int[] move in possibleMoves)
            {
                Board newBoard = board.Clone() as Board;
                int rowIndex = move[0];
                int columnIndex = move[1];

                newBoard.SetFieldColor(rowIndex, columnIndex, color);
                result += newBoard.InvertedDiscsLastMove;
            }
            return result;
        }

        public int GetStableDiscsCount(Board board, DiscColor color)
        {
            return this.GetStableDiscsFromCorner(board, color, 0, 0)
                + this.GetStableDiscsFromCorner(board, color, 0, board.Size - 1)
                + this.GetStableDiscsFromCorner(board, color, board.Size - 1, 0)
                + this.GetStableDiscsFromCorner(board, color, board.Size - 1, board.Size - 1)
                + this.GetStableDiscsFromEdge(board, color, 0, true)
                + this.GetStableDiscsFromEdge(board, color, board.Size - 1, true)
                + this.GetStableDiscsFromEdge(board, color, 0, false)
                + this.GetStableDiscsFromEdge(board, color, board.Size - 1, false);
        }

        private int GetStableDiscsFromCorner(Board board, DiscColor color, int cornerRowIndex, int cornerColumnIndex)
        {
            int result = 0;

            int rowIndexChange = (cornerRowIndex == 0) ? 1 : -1;
            int columnIndexChange = (cornerColumnIndex == 0) ? 1 : -1;

            int rowIndex = cornerRowIndex;
            int rowIndexLimit = (cornerRowIndex == 0) ? board.Size : 0;
            int columnIndexLimit = (cornerColumnIndex == 0) ? board.Size : 0;
            for (rowIndex = cornerRowIndex; rowIndex != rowIndexLimit; rowIndex += rowIndexChange)
            {
                int columnIndex;
                for (columnIndex = cornerColumnIndex; columnIndex != columnIndexLimit; columnIndex += columnIndexChange)
                {
                    if (board[rowIndex, columnIndex] == color)
                    {
                        result++;
                    }
                    else
                    {
                        break;
                    }
                }

                if ((columnIndexChange > 0 && columnIndex < board.Size) || (columnIndexChange < 0 && columnIndex > 0))
                {
                    columnIndexLimit = columnIndex - columnIndexChange;

                    if (columnIndexChange > 0 && columnIndexLimit == 0)
                    {
                        columnIndexLimit++;
                    }
                    else if (columnIndexChange < 0 && columnIndexLimit == board.Size - 1)
                    {
                        columnIndexLimit--;
                    }

                    if ((columnIndexChange > 0 && columnIndexLimit < 0)
                        || (columnIndexChange < 0 && columnIndexLimit > board.Size - 1))
                    {
                        break;
                    }
                }
            }

            return result;
        }

        private int GetStableDiscsFromEdge(Board board, DiscColor color, int edgeCoordinate, bool isHorizontal)
        {
            int result = 0;

            if (IsEdgeFull(board, edgeCoordinate, isHorizontal))
            {
                bool oppositeColorDiscsPassed = false;
                for (int otherCoordinate = 0; otherCoordinate < board.Size; otherCoordinate++)
                {
                    DiscColor fieldColor = (isHorizontal) ? board[edgeCoordinate, otherCoordinate] : board[otherCoordinate, edgeCoordinate];
                    if (fieldColor != color)
                    {
                        oppositeColorDiscsPassed = true;
                    }
                    else if (oppositeColorDiscsPassed)
                    {
                        int consecutiveDiscsCount = 0;
                        while ((otherCoordinate < board.Size) && (fieldColor == color))
                        {
                            consecutiveDiscsCount++;

                            otherCoordinate++;
                            if (otherCoordinate < board.Size)
                            {
                                fieldColor = (isHorizontal) ? board[edgeCoordinate, otherCoordinate] : board[otherCoordinate, edgeCoordinate];
                            }
                        }
                        if (otherCoordinate != board.Size)
                        {
                            result += consecutiveDiscsCount;
                            oppositeColorDiscsPassed = true;
                        }
                    }
                }
            }

            return result;
        }

        private bool IsEdgeFull(Board board, int edgeCoordinate, bool isHorizontal)
        {
            for (int otherCoordinate = 0; otherCoordinate < board.Size; otherCoordinate++)
            {
                if (isHorizontal && (board[edgeCoordinate, otherCoordinate] == DiscColor.None)
                    || !isHorizontal && (board[otherCoordinate, edgeCoordinate] == DiscColor.None))
                {
                    return false;
                }
            }
            return true;
        }

        #endregion
    }

    #endregion
}