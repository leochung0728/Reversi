﻿using Newtonsoft.Json;
using ReversiWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ReversiWebAPI.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // POST api/<controller>
        public object Post([FromBody]ReversiModel model)
        {
            string returnVal = "";
            List<int> possibleMoves = new List<int>() { 0, 0 };
            try
            {
                ReversiObj obj = new ReversiObj(model);
                if (!obj.hasError)
                {
                    int rowIndex;
                    int columnIndex;
                    ComputerPlayer cp = new ComputerPlayer(obj.color, "Computer", obj.maxDepth);
                    MoveSolver ms = new MoveSolver(obj.Board,cp, obj.maxDepth);
                    ms.GetNextMove(out rowIndex, out columnIndex);
                    possibleMoves = new List<int>() { columnIndex, rowIndex };
                }
                else
                {
                    returnVal = obj.error;
                }
            }
            catch (Exception ex)
            {
                returnVal = ex.Message;
            }

            return possibleMoves;
        }


    }
}